package com.example.sensormanagerapp

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class DashboardActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private var userId = 0
    private val SMS_PERMISSION_CODE = 1

    private lateinit var weightEdit: EditText
    private lateinit var dateEdit: EditText
    private lateinit var addButton: Button
    private lateinit var weightList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        dbHelper = DatabaseHelper(this)
        userId = intent.getIntExtra("USER_ID", 0)

        // Bind views
        weightEdit = findViewById(R.id.weightEdit)
        dateEdit = findViewById(R.id.dateEdit)
        addButton = findViewById(R.id.addButton)
        weightList = findViewById(R.id.weightList)

        // Add weight button
        addButton.setOnClickListener {
            val weight = weightEdit.text.toString().toDoubleOrNull()
            val date = dateEdit.text.toString().trim()

            if (weight == null || date.isEmpty()) {
                Toast.makeText(this, "Enter valid date and weight", Toast.LENGTH_SHORT).show()
            } else {
                dbHelper.addWeight(userId, date, weight)
                displayWeights()
                checkGoal(weight)
                weightEdit.text.clear()
                dateEdit.text.clear()
            }
        }

        // Request SMS permission if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                SMS_PERMISSION_CODE
            )
        }

        displayWeights()
    }

    // Display all user weights
    private fun displayWeights() {
        weightList.removeAllViews()
        val cursor: Cursor = dbHelper.getWeights(userId)
        while (cursor.moveToNext()) {
            val date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE))
            val weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT))
            val textView = TextView(this)
            textView.text = "$date : $weight kg"
            textView.textSize = 16f
            textView.setPadding(0, 8, 0, 8)
            weightList.addView(textView)
        }
        cursor.close()
    }

    // Check if user reached goal
    private fun checkGoal(latestWeight: Double) {
        val db = dbHelper.readableDatabase
        val cursor = db.rawQuery(
            "SELECT ${DatabaseHelper.COLUMN_GOAL_WEIGHT} FROM ${DatabaseHelper.TABLE_GOALS} WHERE ${DatabaseHelper.COLUMN_USER_REF}=?",
            arrayOf(userId.toString())
        )

        if (cursor.moveToFirst()) {
            val goalWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_GOAL_WEIGHT))
            if (latestWeight <= goalWeight) {
                sendSmsNotification("Congratulations! You've reached your goal weight: $goalWeight kg")
            }
        }
        cursor.close()
    }

    // Send SMS notification if permission granted
    private fun sendSmsNotification(message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val smsManager = SmsManager.getDefault()
                val phoneNumber = "1234567890" // TODO: Replace with actual number
                smsManager.sendTextMessage(phoneNumber, null, message, null, null)
                Toast.makeText(this, "SMS sent: $message", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    // Handle SMS permission result
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
