package com.example.sensormanagerapp

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "WeightTracker.db"
        private const val DATABASE_VERSION = 1

        // Users table
        const val TABLE_USERS = "users"
        const val COLUMN_USER_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"

        // Daily weights table
        const val TABLE_WEIGHTS = "daily_weights"
        const val COLUMN_WEIGHT_ID = "id"
        const val COLUMN_USER_REF = "user_id"
        const val COLUMN_DATE = "date"
        const val COLUMN_WEIGHT = "weight"

        // Goal weights table
        const val TABLE_GOALS = "goal_weights"
        const val COLUMN_GOAL_ID = "id"
        const val COLUMN_GOAL_WEIGHT = "goal_weight"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create Users table
        val createUsersTable = """
            CREATE TABLE $TABLE_USERS (
                $COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USERNAME TEXT UNIQUE,
                $COLUMN_PASSWORD TEXT
            )
        """.trimIndent()
        db.execSQL(createUsersTable)

        // Create Daily Weights table
        val createWeightsTable = """
            CREATE TABLE $TABLE_WEIGHTS (
                $COLUMN_WEIGHT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USER_REF INTEGER,
                $COLUMN_DATE TEXT,
                $COLUMN_WEIGHT REAL,
                FOREIGN KEY($COLUMN_USER_REF) REFERENCES $TABLE_USERS($COLUMN_USER_ID)
            )
        """.trimIndent()
        db.execSQL(createWeightsTable)

        // Create Goal Weights table
        val createGoalsTable = """
            CREATE TABLE $TABLE_GOALS (
                $COLUMN_GOAL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_USER_REF INTEGER,
                $COLUMN_GOAL_WEIGHT REAL,
                FOREIGN KEY($COLUMN_USER_REF) REFERENCES $TABLE_USERS($COLUMN_USER_ID)
            )
        """.trimIndent()
        db.execSQL(createGoalsTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_WEIGHTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_GOALS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        onCreate(db)
    }

    // -----------------------
    // Users CRUD
    // -----------------------
    fun addUser(username: String, password: String): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        return db.insert(TABLE_USERS, null, values)
    }

    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery(
            "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME=? AND $COLUMN_PASSWORD=?",
            arrayOf(username, password)
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun getUserId(username: String): Int {
        val db = readableDatabase
        val cursor: Cursor = db.rawQuery(
            "SELECT $COLUMN_USER_ID FROM $TABLE_USERS WHERE $COLUMN_USERNAME=?",
            arrayOf(username)
        )
        var id = -1
        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_USER_ID))
        }
        cursor.close()
        return id
    }

    // -----------------------
    // Weights CRUD
    // -----------------------
    fun addWeight(userId: Int, date: String, weight: Double) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_USER_REF, userId)
            put(COLUMN_DATE, date)
            put(COLUMN_WEIGHT, weight)
        }
        db.insert(TABLE_WEIGHTS, null, values)
    }

    fun getWeights(userId: Int): Cursor {
        val db = readableDatabase
        return db.rawQuery(
            "SELECT $COLUMN_DATE, $COLUMN_WEIGHT FROM $TABLE_WEIGHTS WHERE $COLUMN_USER_REF=? ORDER BY $COLUMN_DATE ASC",
            arrayOf(userId.toString())
        )
    }

    fun updateWeight(weightId: Int, newWeight: Double) {
        val db = writableDatabase
        val values = ContentValues().apply { put(COLUMN_WEIGHT, newWeight) }
        db.update(TABLE_WEIGHTS, values, "$COLUMN_WEIGHT_ID=?", arrayOf(weightId.toString()))
    }

    fun deleteWeight(weightId: Int) {
        val db = writableDatabase
        db.delete(TABLE_WEIGHTS, "$COLUMN_WEIGHT_ID=?", arrayOf(weightId.toString()))
    }

    // -----------------------
    // Goal CRUD
    // -----------------------
    fun setGoalWeight(userId: Int, goalWeight: Double) {
        val db = writableDatabase
        // Check if goal exists
        val cursor = db.rawQuery(
            "SELECT $COLUMN_GOAL_ID FROM $TABLE_GOALS WHERE $COLUMN_USER_REF=?",
            arrayOf(userId.toString())
        )
        if (cursor.moveToFirst()) {
            // Update existing goal
            val goalId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_GOAL_ID))
            val values = ContentValues().apply { put(COLUMN_GOAL_WEIGHT, goalWeight) }
            db.update(TABLE_GOALS, values, "$COLUMN_GOAL_ID=?", arrayOf(goalId.toString()))
        } else {
            // Insert new goal
            val values = ContentValues().apply {
                put(COLUMN_USER_REF, userId)
                put(COLUMN_GOAL_WEIGHT, goalWeight)
            }
            db.insert(TABLE_GOALS, null, values)
        }
        cursor.close()
    }
}
